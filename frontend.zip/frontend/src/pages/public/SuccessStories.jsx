import { useEffect, useState } from 'react'
import { storiesApi } from '../../api'

export default function SuccessStories() {
  const [stories, setStories] = useState([])
  useEffect(() => { storiesApi.list().then((r) => setStories(r.data)).catch(() => {}) }, [])

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <p className="tracking-[0.4em] text-brand-gold text-xs">OUR PRIDE</p>
      <h1 className="font-display text-5xl text-brand-green-dark mb-8">Success Stories</h1>

      {stories.length === 0 && <p className="text-gray-500">Player journeys will be highlighted here.</p>}

      <div className="space-y-8">
        {stories.map((s) => (
          <div key={s.id} className="card grid md:grid-cols-3 gap-6 items-center">
            <div className="aspect-square rounded-lg bg-brand-green/10 flex items-center justify-center text-brand-green text-6xl font-display"
                 style={s.image_url ? { backgroundImage: `url(${s.image_url})`, backgroundSize: 'cover', backgroundPosition: 'center' } : {}}>
              {!s.image_url && s.player_name?.[0]}
            </div>
            <div className="md:col-span-2">
              <h3 className="text-3xl text-brand-green-dark">{s.player_name}</h3>
              {s.year && <p className="text-sm text-brand-gold tracking-widest">CLASS OF {s.year}</p>}
              {s.quote && <blockquote className="text-lg italic text-gray-700 mt-3 border-l-4 border-brand-gold pl-4">“{s.quote}”</blockquote>}
              <p className="text-sm text-gray-600 mt-3 whitespace-pre-line">{s.story}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

