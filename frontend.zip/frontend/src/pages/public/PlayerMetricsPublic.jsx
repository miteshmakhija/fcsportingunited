import { useEffect, useState } from 'react'
import { useAuth } from '../../context/AuthContext'
import { playersApi, metricsApi } from '../../api'
import MetricRadar from '../../components/common/MetricRadar'

export default function PlayerMetricsPublic() {
  const { user } = useAuth()
  const [players, setPlayers] = useState([])
  const [selectedId, setSelectedId] = useState('')
  const [latest, setLatest] = useState(null)
  const [error, setError] = useState('')

  useEffect(() => {
    if (user?.role === 'admin') {
      playersApi.list().then((r) => setPlayers(r.data)).catch(() => {})
    }
  }, [user])

  useEffect(() => {
    if (!selectedId) return
    setError('')
    metricsApi.latest(selectedId)
      .then((r) => setLatest(r.data))
      .catch(() => { setLatest(null); setError('No metrics recorded yet for this player.') })
  }, [selectedId])

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <p className="tracking-[0.4em] text-brand-gold text-xs">PERFORMANCE</p>
      <h1 className="font-display text-5xl text-brand-green-dark mb-2">Player Metrics</h1>
      <p className="text-gray-600 mb-8">
        A 360° look at every player's attributes — speed, stamina, technique and tactical IQ.
      </p>

      {user?.role !== 'admin' ? (
        <div className="card text-center bg-brand-green/5">
          <p className="text-brand-green-dark">
            Detailed per-player metrics are visible to <strong>admins</strong> and the player themselves.
            Log in to view your dashboard.
          </p>
        </div>
      ) : (
        <>
          <select
            className="input mb-6 max-w-md"
            value={selectedId}
            onChange={(e) => setSelectedId(e.target.value)}
          >
            <option value="">Select a player…</option>
            {players.map((p) => (
              <option key={p.id} value={p.id}>{p.full_name} {p.position ? `· ${p.position}` : ''}</option>
            ))}
          </select>

          {error && <p className="text-orange-600">{error}</p>}
          {latest && (
            <div className="card">
              <h2 className="text-2xl text-brand-green-dark mb-4">Latest Snapshot</h2>
              <MetricRadar metric={latest} />
            </div>
          )}
        </>
      )}
    </div>
  )
}

