import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import HeroSlider from '../../components/common/HeroSlider'
import { coachesApi, storiesApi } from '../../api'

const BG_PITCH = "url('https://images.unsplash.com/photo-1551958219-acbc608c6377?auto=format&fit=crop&w=1600&q=70')"
const BG_TRAIN = "url('https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&w=1600&q=70')"
const BG_KIDS  = "url('https://images.unsplash.com/photo-1526232761682-d26e03ac148e?auto=format&fit=crop&w=1600&q=70')"

export default function Home() {
  const [stories, setStories] = useState([])
  const [coaches, setCoaches] = useState([])

  useEffect(() => {
    storiesApi.featured().then((r) => setStories(r.data)).catch(() => {})
    coachesApi.list().then((r) => setCoaches(r.data.slice(0, 3))).catch(() => {})
  }, [])

  const slides = [
    {
      eyebrow: 'SPORTING UNITED ACADEMY',
      title: 'Building Tomorrow’s Champions',
      subtitle: 'World-class youth football development, rooted in discipline, joy and ambition.',
      bg: BG_PITCH,
      cta: { label: 'Join the Academy', href: '/login' },
    },
    {
      eyebrow: 'COACHING PHILOSOPHY',
      title: 'Total Football. Total Character.',
      subtitle: 'We develop technical mastery, tactical intelligence and the values to thrive on and off the pitch.',
      bg: BG_TRAIN,
      cta: { label: 'Meet Our Coaches', href: '/coaches' },
    },
    ...stories.slice(0, 3).map((s) => ({
      eyebrow: 'SUCCESS STORY',
      title: s.player_name,
      subtitle: s.quote || s.story?.slice(0, 140),
      bg: BG_KIDS,
      cta: { label: 'Read All Stories', href: '/success-stories' },
    })),
    {
      eyebrow: 'OUR MISSION',
      title: 'Road to the I-League by 2030',
      subtitle: 'A five-year roadmap to launch a professional senior team and put our academy on India’s footballing map.',
      bg: BG_PITCH,
      cta: { label: 'See the Mission', href: '/i-league-mission' },
    },
  ]

  return (
    <div>
      <HeroSlider slides={slides} />

      {/* Philosophy */}
      <section className="max-w-7xl mx-auto px-4 py-16 grid md:grid-cols-3 gap-6">
        {[
          { title: 'TECHNIQUE', body: 'Daily ball-mastery, 1v1s and possession drills. Skill before system.' },
          { title: 'INTELLIGENCE', body: 'Decision-making, scanning, positional play — the football brain.' },
          { title: 'CHARACTER', body: 'Discipline, respect, and resilience — habits of high-performers.' },
        ].map((p) => (
          <div key={p.title} className="card border-t-4 border-brand-gold">
            <h3 className="text-2xl text-brand-green">{p.title}</h3>
            <p className="text-sm text-gray-600 mt-3">{p.body}</p>
          </div>
        ))}
      </section>

      {/* I-League CTA */}
      <section className="bg-brand-green text-white py-16 px-4">
        <div className="max-w-5xl mx-auto text-center">
          <p className="tracking-[0.4em] text-brand-gold text-sm mb-2">2025 — 2030</p>
          <h2 className="font-display text-5xl mb-4">THE ROAD TO I-LEAGUE</h2>
          <p className="text-white/85 max-w-3xl mx-auto mb-8">
            Sporting United Academy is on a five-year mission to launch a senior team in India's I-League.
            Every kid we develop is part of this journey.
          </p>
          <Link to="/i-league-mission" className="btn-gold">View the 5-Year Roadmap</Link>
        </div>
      </section>

      {/* Coaches preview */}
      {coaches.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 py-16">
          <div className="flex items-end justify-between mb-8">
            <div>
              <p className="tracking-[0.4em] text-brand-gold text-xs">OUR TEAM</p>
              <h2 className="font-display text-4xl text-brand-green-dark">Meet the Coaches</h2>
            </div>
            <Link to="/coaches" className="btn-outline">View All</Link>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {coaches.map((c) => (
              <div key={c.id} className="card">
                <div className="w-full aspect-[4/5] rounded-lg bg-brand-green/10 mb-4 flex items-center justify-center text-brand-green text-5xl font-display"
                     style={c.photo_url ? { backgroundImage: `url(${c.photo_url})`, backgroundSize: 'cover', backgroundPosition: 'center' } : {}}>
                  {!c.photo_url && c.name?.[0]}
                </div>
                <h3 className="text-2xl text-brand-green-dark">{c.name}</h3>
                <p className="text-brand-gold text-sm tracking-wider">{c.role_title}</p>
                <p className="text-sm text-gray-600 mt-2 line-clamp-3">{c.bio}</p>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  )
}

