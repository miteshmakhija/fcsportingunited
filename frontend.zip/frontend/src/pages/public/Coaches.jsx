import { useEffect, useState } from 'react'
import { coachesApi } from '../../api'

export default function Coaches() {
  const [coaches, setCoaches] = useState([])
  useEffect(() => { coachesApi.list().then((r) => setCoaches(r.data)).catch(() => {}) }, [])

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <p className="tracking-[0.4em] text-brand-gold text-xs">OUR TEAM</p>
      <h1 className="font-display text-5xl text-brand-green-dark mb-8">Our Coaches</h1>

      {coaches.length === 0 && (
        <p className="text-gray-500">Coaches will appear here once the admin adds them.</p>
      )}

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {coaches.map((c) => (
          <div key={c.id} className="card">
            <div className="w-full aspect-[4/5] rounded-lg bg-brand-green/10 mb-4 flex items-center justify-center text-brand-green text-6xl font-display"
                 style={c.photo_url ? { backgroundImage: `url(${c.photo_url})`, backgroundSize: 'cover', backgroundPosition: 'center' } : {}}>
              {!c.photo_url && c.name?.[0]}
            </div>
            <h3 className="text-2xl text-brand-green-dark">{c.name}</h3>
            <p className="text-brand-gold text-sm tracking-wider">{c.role_title}</p>
            {c.nationality && <p className="text-xs text-gray-500">{c.nationality}{c.years_experience ? ` · ${c.years_experience} yrs exp` : ''}</p>}
            <p className="text-sm text-gray-600 mt-3">{c.bio}</p>
            {Array.isArray(c.certifications) && c.certifications.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-1">
                {c.certifications.map((cert, i) => (
                  <span key={i} className="badge bg-brand-green/10 text-brand-green">{cert}</span>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}

