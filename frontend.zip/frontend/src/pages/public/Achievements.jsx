import { useEffect, useState } from 'react'
import { achievementsApi } from '../../api'

export default function Achievements() {
  const [items, setItems] = useState([])
  useEffect(() => { achievementsApi.list().then((r) => setItems(r.data)).catch(() => {}) }, [])

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <p className="tracking-[0.4em] text-brand-gold text-xs">HONOURS</p>
      <h1 className="font-display text-5xl text-brand-green-dark mb-8">Achievements</h1>

      {items.length === 0 && <p className="text-gray-500">Trophies and milestones will be displayed here.</p>}

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {items.map((a) => (
          <div key={a.id} className="card border-l-4 border-brand-gold">
            <div className="flex items-start justify-between">
              <h3 className="text-xl text-brand-green-dark">{a.title}</h3>
              {a.date_achieved && <span className="text-xs text-gray-500">{new Date(a.date_achieved).toLocaleDateString()}</span>}
            </div>
            {a.category && <span className="badge bg-brand-gold/20 text-brand-green-dark mt-2">{a.category}</span>}
            <p className="text-sm text-gray-600 mt-3">{a.description}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

