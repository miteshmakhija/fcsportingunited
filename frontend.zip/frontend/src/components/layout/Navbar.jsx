import { Link, NavLink, useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'

const linkCls = ({ isActive }) =>
  `px-3 py-2 text-sm font-semibold transition ${
    isActive ? 'text-brand-gold' : 'text-white hover:text-brand-gold'
  }`

export default function Navbar() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()

  const handleLogout = () => {
    logout()
    navigate('/')
  }

  return (
    <header className="bg-brand-green-dark text-white sticky top-0 z-50 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-3">
          <img src="/assets/sua_logo_v1.png" alt="Sporting United Academy" className="h-14 w-auto drop-shadow" />
          <div className="leading-tight">
            <div className="font-display text-xl tracking-wider text-brand-gold">SPORTING UNITED</div>
            <div className="text-[10px] tracking-[0.4em] text-white/70">ACADEMY</div>
          </div>
        </Link>

        <nav className="hidden md:flex items-center gap-1">
          <NavLink to="/" end className={linkCls}>Home</NavLink>
          <NavLink to="/coaches" className={linkCls}>Coaches</NavLink>
          <NavLink to="/achievements" className={linkCls}>Achievements</NavLink>
          <NavLink to="/success-stories" className={linkCls}>Success Stories</NavLink>
          <NavLink to="/player-metrics" className={linkCls}>Player Metrics</NavLink>
          <NavLink to="/i-league-mission" className={linkCls}>I-League Mission</NavLink>
        </nav>

        <div className="flex items-center gap-2">
          {user ? (
            <>
              <Link
                to={user.role === 'admin' ? '/admin' : '/dashboard'}
                className="btn-gold text-sm"
              >
                {user.role === 'admin' ? 'Admin Panel' : 'My Dashboard'}
              </Link>
              <button onClick={handleLogout} className="btn-outline text-sm border-white/40 text-white hover:bg-white hover:text-brand-green">
                Logout
              </button>
            </>
          ) : (
            <Link to="/login" className="btn-gold text-sm">Login</Link>
          )}
        </div>
      </div>
    </header>
  )
}

