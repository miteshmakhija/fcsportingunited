import { Link } from 'react-router-dom'

export default function Footer() {
  return (
    <footer className="bg-brand-ink text-white/80 mt-auto">
      <div className="max-w-7xl mx-auto px-4 py-10 grid md:grid-cols-4 gap-8">
        <div>
          <div className="flex items-center gap-3">
            <img src="/assets/sua_logo_v1.png" alt="Sporting United Academy" className="h-16 w-auto" />
            <div>
              <div className="font-display text-lg text-brand-gold">SPORTING UNITED</div>
              <div className="text-xs tracking-[0.3em] text-white/60">ACADEMY</div>
            </div>
          </div>
          <p className="mt-4 text-sm text-white/60">
            Building tomorrow's champions. On a mission to field an I-League team by 2030.
          </p>
        </div>
        <div>
          <h4 className="text-brand-gold mb-3 text-sm tracking-widest">EXPLORE</h4>
          <ul className="space-y-2 text-sm">
            <li><Link to="/coaches" className="hover:text-brand-gold">Coaches</Link></li>
            <li><Link to="/achievements" className="hover:text-brand-gold">Achievements</Link></li>
            <li><Link to="/success-stories" className="hover:text-brand-gold">Success Stories</Link></li>
            <li><Link to="/player-metrics" className="hover:text-brand-gold">Player Metrics</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-brand-gold mb-3 text-sm tracking-widest">MISSION</h4>
          <ul className="space-y-2 text-sm">
            <li><Link to="/i-league-mission" className="hover:text-brand-gold">Road to I-League</Link></li>
            <li>Coaching Philosophy</li>
            <li>Youth Development</li>
          </ul>
        </div>
        <div>
          <h4 className="text-brand-gold mb-3 text-sm tracking-widest">CONTACT</h4>
          <p className="text-sm text-white/60">academy@sportingunited.com</p>
          <p className="text-sm text-white/60">+91 90000 00000</p>
        </div>
      </div>
      <div className="border-t border-white/10 py-4 text-center text-xs text-white/40">
        © {new Date().getFullYear()} Sporting United Academy. All rights reserved.
      </div>
    </footer>
  )
}

