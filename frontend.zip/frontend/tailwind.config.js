/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        // ────────────────────────────────────────────────────────────
        // 🎨 SPORTING UNITED ACADEMY — central theme palette
        // To re-skin the entire app, change ONLY the hex values below.
        // The semantic keys (primary / accent / etc.) are used everywhere.
        // ────────────────────────────────────────────────────────────
        brand: {
          // ── Primary (current: deep navy, swap to your crest's main colour) ─
          primary:        '#0E1B3A',  // deep navy
          'primary-dark': '#070F22',
          'primary-light':'#1E3270',

          // ── Accent (used for highlights, badges, CTAs) ─
          accent:         '#C8102E',  // crimson red
          'accent-light': '#E63E55',

          // ── Gold trim (logo flourishes, lines, secondary CTAs) ─
          gold:        '#D4AF37',
          'gold-light':'#F0C75E',

          // ── Surfaces ─
          cream: '#F5F1E8',           // page background
          ink:   '#0B1220',           // body text / dark surfaces

          // ── Legacy aliases (so existing components still resolve) ─
          green:        '#0E1B3A',
          'green-dark': '#070F22',
          'green-light':'#1E3270',
        },
      },
      fontFamily: {
        display: ['"Bebas Neue"', 'Impact', 'sans-serif'],
        body: ['Inter', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        crest: '0 10px 30px -10px rgba(14,27,58,0.45)',
      },
    },
  },
  plugins: [],
}
